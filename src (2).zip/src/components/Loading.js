import React from 'react';

const Loading = () => {
	return <p className="container">Loading Data...</p>;
}

export default Loading;
