import React from "react";
import FeedPost from '../components/Posts/FeedPost';

const Rss = () => {
	
	return (
		<React.Fragment>
		
		<FeedPost/>
		
		</React.Fragment>
	);
};

export default Rss;
